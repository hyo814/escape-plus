from django.contrib import admin
from .models import Escapeuser
# Register your models here.

class EscapeuserAdmin(admin.ModelAdmin):
       list_display = ('username','password')

admin.site.register(Escapeuser,EscapeuserAdmin)